//
//  ZoomAuthentication.h
//  ZoomAuthentication
//
//  Created by FaceTec, Inc. on 3/15/16.
//  Copyright © 2017 FaceTec, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZoomAuthentication.
FOUNDATION_EXPORT double ZoomAuthenticationVersionNumber;

//! Project version string for ZoomAuthentication.
FOUNDATION_EXPORT const unsigned char ZoomAuthenticationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZoomAuthentication/PublicHeader.h>
